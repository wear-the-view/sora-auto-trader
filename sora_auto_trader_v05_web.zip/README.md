# SORA AUTO TRADER v0.5 Web — DEMO ONLY

AndroidのChromeで使えるGitHub Pages用の静的Webアプリ。**実際の発注は一切行いません**。

## Androidから公開する

1. GitHubで無料アカウントを作成し、新しい **Public** リポジトリ `sora-auto-trader` を作成する。
2. リポジトリの **Add file → Upload files** で `index.html` と `fetch_data.py` をアップロードする。
3. GitHubの **Add file → Create new file** で `.github/workflows/update.yml` を作り、配布ZIPの同名ファイルの内容を貼り付けて保存する。AndroidではChromeの「PC版サイト」を使うと操作しやすい。
4. **Settings → Actions → General → Workflow permissions** で **Read and write permissions** を選ぶ（設定可能な場合）。
5. **Actions → Update market data → Run workflow** を実行する。成功すると `data/GOLD.json` 等が作られる。外部APIの制限で失敗する場合があり、その際はデータが更新されない。
6. **Settings → Pages → Build and deployment → Deploy from a branch → main / (root) → Save** を選ぶ。数分後にPagesの公開URLが表示される。
7. 公開URLをAndroidで開き「3市場を取得」を押す。最終足の日付とデータ出典を確認する。

## 注意

- **PublicリポジトリとGitHub PagesのURLは公開される**。口座情報・パスワード・APIキー・個人情報を絶対にアップロードしない。
- GitHub Actionsのスケジュール実行は遅延・停止する場合がある。毎日必ず更新される保証はない。
- GOLDは **金先物 GC=F** で現物XAUUSDとは異なる。BTCはBTC-USD、ドル円はJPY=X。取引所やブローカーの約定価格ではない。
- 公開価格データの取得可否・利用条件は提供元に依存する。Yahoo Finance側の制限により更新失敗することがある。
- 元のバックテストは単純な移動平均戦略で、将来利益の根拠にはならない。各市場の通貨・契約仕様が異なるため、損益は実際の円建て運用を厳密に再現しない。
- これはクラウドで24時間**自動売買するシステムではない**。データを定期更新してブラウザでバックテストする段階。
- CSVを直接読み込む機能は引き続き使用可能。
